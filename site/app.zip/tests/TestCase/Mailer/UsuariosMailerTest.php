<?php
namespace App\Test\TestCase\Mailer;

use App\Mailer\UsuariosMailer;
use Cake\TestSuite\TestCase;

/**
 * App\Mailer\UsuariosMailer Test Case
 */
class UsuariosMailerTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Mailer\UsuariosMailer
     */
    public $Usuarios;

    /**
     * Test initial setup
     *
     * @return void
     */
    public function testInitialization()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
